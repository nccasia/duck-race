export default interface ISocketService {}
