export const Environments = {
    DEVELOPMENT: "development",
    PRODUCTION: "production",
    STAGING: "staging",
    PRE_RELEASE: "pre-release",
    TEST: "test",
}