export const Securities = {
    SALTS: 10,
    REDIS_EXPIRATION:60, // Unit: seconds
    DEFAULT_PASSWORD_PREFIX: "NCC@",
}