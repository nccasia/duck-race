export const LocalStorage = {
    REQUEST_STORE: "requestStore"
}