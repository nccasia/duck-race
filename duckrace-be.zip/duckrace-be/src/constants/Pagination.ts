export const Pagination = {
    DEFAULT_PAGE: 1,
    DEFAULT_LIMIT: 10
}