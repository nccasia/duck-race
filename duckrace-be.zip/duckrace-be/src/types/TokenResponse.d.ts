type TokenResponse = {
    id: string;
    token: string;
    expiresAt: Date;
    expiresAtUtc: string;
};