
type CurrentUser = {
    id: string;
    userName?: string;
};