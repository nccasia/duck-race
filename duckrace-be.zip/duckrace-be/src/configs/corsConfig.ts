export const corsConfig = {
  origin: ["http://localhost:5173", "https://admin.socket.io", "https://duckrace.vncsoft.com", "https://duck-race.nccsoft.vn"],
  credentials: true,
};
